from django.contrib.auth import login
from django.shortcuts import render, redirect,  get_object_or_404
from .models import StudentApplication, UserProfile, Video, PDF, Announcement, CourseMaterial
from django.contrib import messages
from .forms import UserRegistrationForm,CourseMaterialForm, AnnouncementForm
from django.http import JsonResponse
from django.contrib.auth.hashers import make_password, check_password



def index_view(request):
    return render(request, 'learnbetter/index.html')

def about_view(request):
    return render(request, 'learnbetter/about.html')

def contact_view(request):
    return render(request, 'learnbetter/contact.html')

def news_view(request):
    return render(request, 'learnbetter/news.html')

def courses_view(request):
    return render(request, 'learnbetter/courses.html')

def elements_view(request):
    return render(request, 'learnbetter/elements.html')

def lecturers_view(request):
    return render(request, 'learnbetter/lecturers.html')

def login_view(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']

        try:
            # Retrieve the user by email
            user = UserProfile.objects.get(email=email)

            # Check if the password matches
            if check_password(password, user.password):
                # Check the role and redirect accordingly
                if user.role == 'student':
                    return redirect('student_dashboard_1')
                elif user.role == 'lecturer':
                    return redirect('lecturer_dashboard_1')
            else:
                messages.error(request, 'Invalid email or password.')
        except UserProfile.DoesNotExist:
            messages.error(request, 'Invalid email or password.')

    return render(request, 'learnbetter/login.html')

#Register View for handling registration data
def register_view(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)  # Don't save yet
            user.password = make_password(user.password)  # Hash password
            user.save()  # Now save the user to the database
            messages.success(request, 'Registration successful. You can now log in.')
            return redirect('login')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = UserRegistrationForm()

    return render(request, 'learnbetter/register.html', {'form': form})

#Student Application
def student_application_view(request):
    if request.method == 'POST':
        application = StudentApplication(
            first_name=request.POST['first_name'],
            last_name=request.POST['last_name'],
            date_of_birth=request.POST['date_of_birth'],
            gender=request.POST['gender'],
            role=request.POST['role'],
            email=request.POST['email'],
            phone_number=request.POST['phone_number'],
            address=request.POST['address'],
            educational_institution=request.POST['educational_institution'],
            grade=request.POST['grade'],
            parent_name=request.POST['parent_name'],
            parent_phone=request.POST['parent_phone'],
            proof_of_payment=request.FILES['proof_of_payment'],
            certified_id=request.FILES['certified_id'],
            proof_of_address=request.FILES['proof_of_address'],
            latest_qualification=request.FILES['latest_qualification'],
            certified_parent_id=request.FILES['certified_parent_id'],
        )
        application.save()
        return redirect('login')  # Redirect to test page after saving

    return render(request, 'learnbetter/application.html')

def test_view(request):
    # Retrieve all student applications from the database
    applications = StudentApplication.objects.all()  # Adjust as needed for filtering
    
    # Pass the applications to the template
    return render(request, 'learnbetter/test.html', {'applications': applications})

def application_success(request):
    return render(request, 'learnbetter/application_success.html')

def student_view(request):
    return render(request, 'learnbetter/student_dashboard.html')

def payment_view(request):
    return render(request, 'learnbetter/payment.html')  

# Manage courses
def manage_course_view(request):
    if request.method == 'POST':
        # Handling video upload
        if 'videoUpload' in request.FILES:
            video_file = request.FILES['videoUpload']
            try:
                Video.objects.create(video_file=video_file)
                return JsonResponse({'success': True, 'message': 'Video uploaded successfully.'})
            except Exception as e:
                return JsonResponse({'success': False, 'message': str(e)})

        # Handling PDF upload
        if 'pdfUpload' in request.FILES:
            pdf_file = request.FILES['pdfUpload']
            try:
                PDF.objects.create(pdf_file=pdf_file)
                return JsonResponse({'success': True, 'message': 'PDF uploaded successfully.'})
            except Exception as e:
                return JsonResponse({'success': False, 'message': str(e)})

        # Handling announcement
        if 'announcement' in request.POST:
            announcement_content = request.POST.get('announcement')
            try:
                Announcement.objects.create(content=announcement_content)
                return JsonResponse({'success': True, 'message': 'Announcement posted successfully.'})
            except Exception as e:
                return JsonResponse({'success': False, 'message': str(e)})

    return render(request, 'learnbetter/manage_courses.html')  # Render the same page

def manage_students_view(request):
    return render(request, 'learnbetter/manage_students.html')

def schedule_view(request):
    return render(request, 'learnbetter/schedule.html')

def assignments_view(request):
    return render(request, 'learnbetter/assignments.html')

def messages_view(request):
    return render(request, 'learnbetter/messages.html')

def profile_settings_view(request):
    return render(request, 'learnbetter/profile_settings.html')

def lecturer_dashboard(request):
    materials = CourseMaterial.objects.all()
    announcements = Announcement.objects.all()

    if request.method == 'POST':
        # Handle deletion of course materials
        if 'delete_material_id' in request.POST:
            material_id = request.POST.get('delete_material_id')
            material = get_object_or_404(CourseMaterial, id=material_id)
            material.delete()
            return redirect('lecturer_dashboard_1')

        # Handle deletion of announcements
        elif 'delete_announcement_id' in request.POST:
            announcement_id = request.POST.get('delete_announcement_id')
            announcement = get_object_or_404(Announcement, id=announcement_id)
            announcement.delete()
            return redirect('lecturer_dashboard_1')

        # Handle course material upload
        material_form = CourseMaterialForm(request.POST, request.FILES)
        if material_form.is_valid():
            material_form.save()
            return redirect('lecturer_dashboard_1')

        # Handle posting announcements
        announcement_form = AnnouncementForm(request.POST)
        if announcement_form.is_valid():
            announcement_form.save()
            return redirect('lecturer_dashboard_1')

    else:
        material_form = CourseMaterialForm()
        announcement_form = AnnouncementForm()

    context = {
        'materials': materials,
        'announcements': announcements,
        'material_form': material_form,
        'announcement_form': announcement_form
    }
    return render(request, 'learnbetter/dashboard.html', context)

def student_dashboard(request):
    materials = CourseMaterial.objects.all()
    announcements = Announcement.objects.all()
    
    context = {
        'materials': materials,
        'announcements': announcements,
    }
    return render(request, 'learnbetter/student_dashboard_1.html', context)

# View for Data Science course
def data_science_view(request):
    return render(request, 'learnbetter/data_science.html')
 
def cybersecurity_view(request):
    return render(request, 'learnbetter/cybersecurity.html')
 
# View for AI and Machine Learning course
 
def ai_ml_view(request):
    return render(request, 'learnbetter/ai_ml.html')
 
# View for Cloud Computing course
def cloud_computing_view(request):
    return render(request, 'learnbetter/cloud_computing.html')
 
# View for Fullstack Web Development course
def full_stack_web_development_view(request):
    return render(request, 'learnbetter/full_stack_web_development.html')
 
# View for Blockchain Technology course
def blockchain_view(request):
    return render(request, 'learnbetter/blockchain.html')
 
# View for Digital Marketing course
def digital_marketing_view(request):
    return render(request, 'learnbetter/digital_marketing.html')
 
# View for UX/UI Design course
def ux_ui_design_view(request):
    return render(request, 'learnbetter/ux_ui_design.html')
 
# View for Project Management course
def project_management_view(request):
    return render(request, 'learnbetter/project_management.html')
 
# View for DevOps Engineering course
def devops_engineering_view(request):
    return render(request, 'learnbetter/devops_engineering.html')
