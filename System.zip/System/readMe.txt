Add the following in your settings.py

-----------------------------------

import os

-----------------------------------

INSTALLED_APPS = [
    '''other apps '''
    'learnbetter', #app name
]

-----------------------------------

STATIC_URL = 'static/'
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')  # Directory to store uploaded files
