from django.contrib import admin
from django.utils.html import format_html
from django.core.mail import send_mass_mail
from django.http import HttpResponse
import csv
from .models import StudentApplication, UserProfile, UploadedFile, AcceptedStudent, CourseMaterial, Announcement

@admin.register(StudentApplication)
class StudentApplicationAdmin(admin.ModelAdmin):
    list_display = (
        'first_name', 
        'last_name', 
        'date_of_birth', 
        'gender', 
        'email', 
        'phone_number', 
        'address', 
        'grade',
        'educational_institution',
        'is_accepted',  # Show acceptance status
        'get_proof_of_payment',  
        'get_certified_id',     
        'get_proof_of_address',  
        'get_latest_qualification',  
        'get_certified_parent_id',     
    )
    
    search_fields = ('first_name', 'last_name', 'email')
    list_filter = ('gender', 'grade', 'is_accepted')  # Added acceptance status filter
    actions = ['accept_students', 'export_accepted_students', 'send_bulk_emails']

    fields = (
        'first_name', 
        'last_name', 
        'date_of_birth', 
        'gender', 
        'email', 
        'phone_number', 
        'address', 
        'grade',
        'educational_institution',
        'proof_of_payment',  
        'certified_id',
        'proof_of_address',
        'latest_qualification',
        'certified_parent_id',
        'is_accepted',  # Make it editable
    )

    def get_proof_of_payment(self, obj):
        if obj.proof_of_payment:
            return format_html('<a href="{}">Download</a>', obj.proof_of_payment.url)
        return "-"
    get_proof_of_payment.short_description = 'Proof of Payment'

    def get_certified_id(self, obj):
        if obj.certified_id:
            return format_html('<a href="{}">Download</a>', obj.certified_id.url)
        return "-"
    get_certified_id.short_description = 'Certified ID'

    def get_proof_of_address(self, obj):
        if obj.proof_of_address:
            return format_html('<a href="{}">Download</a>', obj.proof_of_address.url)
        return "-"
    get_proof_of_address.short_description = 'Proof of Address'

    def get_latest_qualification(self, obj):
        if obj.latest_qualification:
            return format_html('<a href="{}">Download</a>', obj.latest_qualification.url)
        return "-"
    get_latest_qualification.short_description = 'Latest Qualification'

    def get_certified_parent_id(self, obj):
        if obj.certified_parent_id:
            return format_html('<a href="{}">Download</a>', obj.certified_parent_id.url)
        return "-"
    get_certified_parent_id.short_description = 'Certified Parent ID'

    def accept_students(self, request, queryset):
        """Move accepted students to the AcceptedStudent table."""
        accepted = 0
        for application in queryset:
            if not application.is_accepted:
                application.is_accepted = True
                application.save()
                AcceptedStudent.objects.create(application=application)
                accepted += 1
        self.message_user(request, f"{accepted} student(s) accepted and moved.")
    accept_students.short_description = "Accept selected students"

    def export_accepted_students(self, request, queryset):
        """Generate a CSV report of accepted students."""
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="accepted_students.csv"'

        writer = csv.writer(response)
        writer.writerow(['First Name', 'Last Name', 'Email', 'Phone', 'Accepted At'])

        accepted_students = AcceptedStudent.objects.filter(application__in=queryset)
        for student in accepted_students:
            writer.writerow([
                student.application.first_name,
                student.application.last_name,
                student.application.email,
                student.application.phone_number,
                student.accepted_at,
            ])

        return response
    export_accepted_students.short_description = "Export accepted students as CSV"

    def send_bulk_emails(self, request, queryset):
        """Send bulk emails to accepted students."""
        emails = []
        accepted_students = AcceptedStudent.objects.filter(application__in=queryset)

        for student in accepted_students:
            if not student.email_sent:
                emails.append((
                    "Congratulations!",
                    "You have been accepted.",
                    "admin@university.com",  # From email
                    [student.application.email]
                ))
                student.email_sent = True
                student.save()

        if emails:
            send_mass_mail(emails, fail_silently=False)
            self.message_user(request, f"Sent {len(emails)} email(s) successfully.")
        else:
            self.message_user(request, "No new emails to send.")
    send_bulk_emails.short_description = "Send bulk emails to accepted students"

@admin.register(AcceptedStudent)
class AcceptedStudentAdmin(admin.ModelAdmin):
    list_display = ('application', 'accepted_at', 'email_sent')
    search_fields = ('application__first_name', 'application__last_name', 'application__email')

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email', 'role', 'age', 'gender')
    search_fields = ('first_name', 'last_name', 'email')
    list_filter = ('gender', 'role')

@admin.register(UploadedFile)
class UploadedFileAdmin(admin.ModelAdmin):
    list_display = ('get_video', 'get_pdf', 'announcement')
    search_fields = ('announcement',)

    def get_video(self, obj):
        if obj.video:
            return format_html('<a href="{}">Download Video</a>', obj.video.url)
        return "-"
    get_video.short_description = 'Video'

    def get_pdf(self, obj):
        if obj.pdf:
            return format_html('<a href="{}">Download PDF</a>', obj.pdf.url)
        return "-"
    get_pdf.short_description = 'PDF'
    
admin.site.register(CourseMaterial)
admin.site.register(Announcement)
