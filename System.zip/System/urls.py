from django.urls import path
from .views import index_view, about_view, contact_view, news_view, courses_view, elements_view,lecturers_view,login_view, register_view, student_application_view, student_view, application_success, payment_view,manage_course_view,manage_students_view,schedule_view,assignments_view,messages_view,profile_settings_view, test_view, lecturer_dashboard, student_dashboard, data_science_view,ai_ml_view,cybersecurity_view,cloud_computing_view,full_stack_web_development_view,blockchain_view,digital_marketing_view, ux_ui_design_view,project_management_view,devops_engineering_view

urlpatterns = [
    path('', index_view, name='index'),
    path('about/', about_view, name='about'),
    path('contact/', contact_view, name='contact'),
    path('news/', news_view, name='news'),
    path('courses/', courses_view, name='courses'),
    path('elements/', elements_view, name='elements'),
    path('lecturers/',  lecturers_view, name='lecturers'),
    path('login/', login_view, name='login'),
    path('student/', student_view, name='lecturer_dashboard'),
    path('register/', register_view, name='register'),
    
    path('application/', student_application_view, name='student_application_view'),
    path('submit-application/', application_success, name='application_success'),
    path('application-success/', application_success, name='application_success'),
    
    
    path('payment/', payment_view, name='payment'),
    path('manage_courses/', manage_course_view, name='manage_courses'),
    path('manage_students/', manage_students_view, name='manage_students'),
    path('schedule/', schedule_view, name='schedule'),
    path('assignments/', assignments_view, name='assignments'),
    path('messages/', messages_view, name='messages'),
    path('profile_settings/', profile_settings_view, name='profile_settings'),
    
    #Courses tabs
    path('cybersecurity/', cybersecurity_view, name='cybersecurity'),
    path('data-science/', data_science_view, name='data_science'),
    path('ai-ml/', ai_ml_view, name='ai_ml'),
    path('cloud-computing/', cloud_computing_view, name='cloud_computing'),
    path('full_stack-web-development/', full_stack_web_development_view, name='full_stack_web_development'),
    path('blockchain/', blockchain_view, name='blockchain'),
    path('digital-marketing/', digital_marketing_view, name='digital_marketing'),
    path('ux-ui-design/', ux_ui_design_view, name='ux_ui_design'),
    path('project-management/', project_management_view, name='project_management'),
    path('devops-engineering/', devops_engineering_view, name='devops_engineering'),
    
    #Testing
    path('submit-application/', student_application_view, name='submit-application'),
    path('application-success/', application_success, name='application-success'),
    path('test/', test_view, name='test'),  # URL for testing
    
    #Test 2
    path('dashboard/', lecturer_dashboard, name='lecturer_dashboard_1'),
    path('student_dashboard/', student_dashboard, name='student_dashboard_1'),


]