from django.db import models
from django.contrib.auth.models import User


class StudentApplication(models.Model):
    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ]
    ROLE_CHOICES = [
        ('student', 'Student'),
        ('lecturer', 'Lecturer'),
    ]

    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)
    email = models.EmailField()
    phone_number = models.CharField(max_length=15)
    address = models.CharField(max_length=255)
    educational_institution = models.CharField(max_length=255)
    grade = models.CharField(max_length=50)
    parent_name = models.CharField(max_length=100)
    parent_phone = models.CharField(max_length=15)

    proof_of_payment = models.FileField(upload_to='proofs/')
    certified_id = models.FileField(upload_to='ids/')
    proof_of_address = models.FileField(upload_to='addresses/')
    latest_qualification = models.FileField(upload_to='qualifications/')
    certified_parent_id = models.FileField(upload_to='parent_ids/')
    
    is_accepted = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class AcceptedStudent(models.Model):
    application = models.OneToOneField(StudentApplication, on_delete=models.CASCADE)
    accepted_at = models.DateTimeField(auto_now_add=True)
    email_sent = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.application.first_name} {self.application.last_name}"


class UserProfile(models.Model):
    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ]
    ROLE_CHOICES = [
        ('student', 'Student'),
        ('lecturer', 'Lecturer'),
    ]

    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=15)
    address = models.TextField()
    id_number = models.CharField(max_length=20, unique=True)
    age = models.PositiveIntegerField()
    gender = models.CharField(max_length=6, choices=GENDER_CHOICES)
    role = models.CharField(max_length=8, choices=ROLE_CHOICES)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=128)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class Course(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    lecturer = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.title


class Video(models.Model):
    course = models.ForeignKey(Course, related_name='videos', on_delete=models.CASCADE)
    video_file = models.FileField(upload_to='videos/')

    def __str__(self):
        return f"Video for {self.course.title}"


class PDF(models.Model):
    course = models.ForeignKey(Course, related_name='pdfs', on_delete=models.CASCADE)
    pdf_file = models.FileField(upload_to='pdfs/')

    def __str__(self):
        return f"PDF for {self.course.title}"

# New models
class CourseMaterial(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    upload_date = models.DateTimeField(auto_now_add=True)

    pdf_file = models.FileField(upload_to='course_pdfs/', blank=True, null=True)
    video_file = models.FileField(upload_to='course_videos/', blank=True, null=True)

    def __str__(self):
        return self.title

class Announcement(models.Model):
    title = models.CharField(max_length=100)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class UploadedFile(models.Model):
    video = models.FileField(upload_to='videos/', blank=True, null=True)
    pdf = models.FileField(upload_to='pdfs/', blank=True, null=True)
    announcement = models.TextField(blank=True)

    def __str__(self):
        return f"Uploaded File {self.id}"
